package hello.security.main.entities;

public enum EnrollmentStatus {

	PENDING, APPROVED, REJECTED, UNENROLLED;
}
