package hello.security.main.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import hello.security.main.entities.EnrollmentEntity;
import hello.security.main.entities.EnrollmentStatus;
import hello.security.main.entities.StudentEntity;
@Repository
public interface EnrollmentRepository extends JpaRepository<EnrollmentEntity, Long>{
	 List<EnrollmentEntity> findByStudentAndStatusIn(
	            StudentEntity student,
	            List<EnrollmentStatus> statuses
	    );

	List<EnrollmentEntity> findByStudent(StudentEntity student);

	List<EnrollmentEntity> findByStatus(EnrollmentStatus pending);
	
}
