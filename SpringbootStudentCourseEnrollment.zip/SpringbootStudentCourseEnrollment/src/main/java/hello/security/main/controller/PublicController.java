package hello.security.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import hello.security.main.entities.StudentEntity;
import hello.security.main.repository.StudentRepository;
import hello.security.main.serviceLayer.ServiceInterface;

@Controller
@RequestMapping("/public")

public class PublicController {

	@Autowired
	private ServiceInterface si;
	
	@Autowired
	private StudentRepository sr;
	@GetMapping("/")
	public String index() {
		return "index";
	}
	
	@GetMapping("/login")
	public String login(Model model) {
		model.addAttribute("modelObj", new StudentEntity());
		return"login";
	}
	@GetMapping("/register")
	public String register(Model model) {
		model.addAttribute("modelObj", new StudentEntity());
		return"register";
	}
	
	@PostMapping("/registerUser")
	public String registerUser(@ModelAttribute StudentEntity se) {
		si.registerUser(se);
        return "/user-dashboard";
	}
	
	
}
