package hello.security.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootStudentCourseEnrollmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootStudentCourseEnrollmentApplication.class, args);
	}

}
