package hello.security.main.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import hello.security.main.entities.EnrollmentEntity;
import hello.security.main.entities.EnrollmentStatus;
import hello.security.main.entities.StudentEntity;
import hello.security.main.repository.CourseRepository;
import hello.security.main.repository.EnrollmentRepository;
import hello.security.main.repository.StudentRepository;
import hello.security.main.serviceLayer.ServiceInterface;

@Controller
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private ServiceInterface si;
	@Autowired
	private StudentRepository sr;
	@Autowired
	private CourseRepository cr;
	@Autowired
	private EnrollmentRepository er;
	
	
	@GetMapping("/user-dashboard")
	String dashboard(Model model) {
		model.addAttribute("modelObj", si.getAllCourses());
		return "user-dashboard";
	}
	
	@PostMapping("/enroll/{courseId}")
	public String enrollCourse(@PathVariable Long courseId,
	                           Authentication authentication, RedirectAttributes redirectAttributes) {
		String email = authentication.getName(); // logged-in user
	    si.enrollRequest(email, courseId);

	    redirectAttributes.addFlashAttribute(
	            "enrollSuccess",
	            "Enroll request sent. Please wait for admin approval."
	        );
	    return "redirect:/user/user-dashboard";
	}
	
	/////
	 @GetMapping("/my-enrollments")
	    public String myEnrollments(Model model, Principal principal) {

	        String email = principal.getName();

	        StudentEntity student = sr
	                .findByEmail(email);
	        // only PENDING & APPROVED
	        List<EnrollmentEntity> enrollments =
	                er.findByStudentAndStatusIn(
	                        student,
	                        List.of(
	                                EnrollmentStatus.PENDING,
	                                EnrollmentStatus.APPROVED
	                        )
	                );

	        model.addAttribute("modelObj", enrollments);
	        return "my-enrollments";
	    }
	 //
	 
	 @GetMapping("/enrollment-history")
	 String enrollmentHistory(Model model, Principal principal) {

	     String email = principal.getName();
	     StudentEntity student = sr
	             .findByEmail(email);
	     List<EnrollmentEntity> history =
	             er.findByStudent(student);

	     model.addAttribute("modelObj", history);

	     return "enrollment-history";
	 }
	 
	 @PostMapping("/unenroll/{id}")
	 String unEnroll(@PathVariable Long id, RedirectAttributes ra) {
		 si.unEnroll(id);
		 ra.addFlashAttribute(
		            "unenroll",
		            "Unenrolled Successfull! "
		        );
		    return "redirect:/user/my-enrollments";
	 }

	}

	

