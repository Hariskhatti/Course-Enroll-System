package hello.security.main;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import hello.security.main.entities.CourseEntity;
import hello.security.main.entities.EnrollmentEntity;
import hello.security.main.entities.EnrollmentStatus;
import hello.security.main.entities.RoleEntity;
import hello.security.main.entities.StudentEntity;
import hello.security.main.repository.CourseRepository;
import hello.security.main.repository.EnrollmentRepository;
import hello.security.main.repository.RoleRepository;
import hello.security.main.repository.StudentRepository;
import hello.security.main.serviceLayer.ServiceInterface;

@Service
public class ServiceClass implements ServiceInterface , UserDetailsService{

	@Autowired
	private StudentRepository sr;
	@Autowired
	private PasswordEncoder encoder;
	@Autowired
	private RoleRepository roleRepo;
	@Autowired
	private CourseRepository cr;
	@Autowired
	private EnrollmentRepository er;
	
	@Override
	public StudentEntity registerUser(StudentEntity se) {
		se.setPassword(encoder.encode(se.getPassword()));
		RoleEntity userRole = roleRepo.findByRoleName("ROLE_USER");
	    se.setRoles(Set.of(userRole));	
	    return sr.save(se);
		
	}
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		StudentEntity se = sr.findByEmail(username);
		 return org.springframework.security.core.userdetails.User
				    .withUsername(se.getEmail())
				    .password(se.getPassword())
				    .authorities(
				        se.getRoles().stream()
				            .map(role -> new SimpleGrantedAuthority(role.getRoleName()))
				            .toList()
				    )
				    .accountExpired(false)
				    .accountLocked(false)
				    .credentialsExpired(false)
				    .disabled(false)   // VERY IMPORTANT
				    .build();  
		 }
	@Override
	public CourseEntity saveCourse(CourseEntity ce) {
		return cr.save(ce);
	}
	@Override
	public List<CourseEntity> getAllCourses() {
		return cr.findAll();
	}
	@Override
	public void deleteCourseById(long id) {
		 cr.deleteById(id);
	}
	@Override
	public EnrollmentEntity enrollRequest(String email, Long courseId) {
		StudentEntity se = sr.findByEmail(email);
		CourseEntity ce = cr.findById(courseId).orElseThrow(() -> new RuntimeException ("Course not found exception"));
		EnrollmentEntity ee = new EnrollmentEntity();
		ee.setStudent(se);
		ee.setCourse(ce);
		ee.setEnrolledAt(LocalDate.now());
	    ee.setStatus(EnrollmentStatus.PENDING);
		return er.save(ee);
	}
	@Override
	public EnrollmentEntity approveRequest(Long enrollId, StudentEntity logedInAdmin) {
		EnrollmentEntity ee = er.findById(enrollId).orElseThrow();
		ee.setApprovedAt(LocalDate.now());
		ee.setStatus(EnrollmentStatus.APPROVED);
		ee.setActionByAdmin(logedInAdmin);
		
		return er.save(ee);
	}
	@Override
	public EnrollmentEntity rejectRequest(Long enrollId, StudentEntity logedInAdmin) {
		EnrollmentEntity ee = er.findById(enrollId).orElseThrow();
		ee.setRejectedAt(LocalDate.now());
		ee.setStatus(EnrollmentStatus.REJECTED);
		ee.setActionByAdmin(logedInAdmin);
		
		return er.save(ee);
	}
	@Override
	public EnrollmentEntity unEnroll(Long id) {
		EnrollmentEntity ee = er.findById(id).orElseThrow();
		ee.setUnenrolledAt(LocalDate.now());
		ee.setStatus(EnrollmentStatus.UNENROLLED);		
		return er.save(ee);	}
	
	
}
