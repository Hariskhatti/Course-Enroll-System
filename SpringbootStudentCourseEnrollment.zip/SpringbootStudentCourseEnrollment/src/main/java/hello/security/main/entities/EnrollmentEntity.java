package hello.security.main.entities;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "enrollments")
public class EnrollmentEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long enrollId;

    // MANY enrollments -> ONE student (who applied)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private StudentEntity student;

    // MANY enrollments -> ONE course
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "course_id", nullable = false)
    private CourseEntity course;

    // 🔥 ADMIN who approved/rejected (actually StudentEntity with ROLE_ADMIN)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "action_by_admin_id")
    private StudentEntity actionByAdmin;

    @Enumerated(EnumType.STRING)
    private EnrollmentStatus status;

    private LocalDate enrolledAt;
    private LocalDate approvedAt;
    private LocalDate rejectedAt;
    private LocalDate unenrolledAt;

    // ===== getters & setters =====

    public Long getEnrollId() {
        return enrollId;
    }

    public void setEnrollId(Long enrollId) {
        this.enrollId = enrollId;
    }

    public StudentEntity getStudent() {
        return student;
    }

    public void setStudent(StudentEntity student) {
        this.student = student;
    }

    public CourseEntity getCourse() {
        return course;
    }

    public void setCourse(CourseEntity course) {
        this.course = course;
    }

    public StudentEntity getActionByAdmin() {
        return actionByAdmin;
    }

    public void setActionByAdmin(StudentEntity actionByAdmin) {
        this.actionByAdmin = actionByAdmin;
    }

    public EnrollmentStatus getStatus() {
        return status;
    }

    public void setStatus(EnrollmentStatus status) {
        this.status = status;
    }

    public LocalDate getEnrolledAt() {
        return enrolledAt;
    }

    public void setEnrolledAt(LocalDate enrolledAt) {
        this.enrolledAt = enrolledAt;
    }

    public LocalDate getApprovedAt() {
        return approvedAt;
    }

    public void setApprovedAt(LocalDate localDate) {
        this.approvedAt = localDate;
    }

    public LocalDate getRejectedAt() {
        return rejectedAt;
    }

    public void setRejectedAt(LocalDate rejectedAt) {
        this.rejectedAt = rejectedAt;
    }

    public LocalDate getUnenrolledAt() {
        return unenrolledAt;
    }

    public void setUnenrolledAt(LocalDate unenrolledAt) {
        this.unenrolledAt = unenrolledAt;
    }
}
