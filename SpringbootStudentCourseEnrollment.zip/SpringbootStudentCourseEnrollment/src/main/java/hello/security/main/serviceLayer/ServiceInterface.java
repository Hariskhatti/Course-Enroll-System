package hello.security.main.serviceLayer;

import java.util.List;

import hello.security.main.entities.CourseEntity;
import hello.security.main.entities.EnrollmentEntity;
import hello.security.main.entities.StudentEntity;

public interface ServiceInterface {

	// StudentMethods
	StudentEntity registerUser(StudentEntity se);
	
	//CourseMethods
	CourseEntity saveCourse(CourseEntity ce);
	List<CourseEntity> getAllCourses();
	void deleteCourseById(long id);
	
	//EnrollmentMethods
	EnrollmentEntity enrollRequest(String email, Long courseId);
	EnrollmentEntity approveRequest(Long enrollId, StudentEntity se);
	EnrollmentEntity rejectRequest(Long enrollId, StudentEntity se);
	EnrollmentEntity unEnroll(Long id);

}
