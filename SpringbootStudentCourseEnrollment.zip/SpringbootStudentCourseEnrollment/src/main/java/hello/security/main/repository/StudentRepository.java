package hello.security.main.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import hello.security.main.entities.StudentEntity;
@Repository
public interface StudentRepository extends JpaRepository<StudentEntity, Long>{

	StudentEntity findByEmail(String email);
	
}
