package hello.security.main.securityConfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

	@Bean
	SecurityFilterChain securityFilterChain(HttpSecurity http) {
		http.csrf(Customizer -> Customizer.disable());
		http.authorizeHttpRequests(auth -> auth.requestMatchers("/","/admin/login","/login","/public/**").permitAll()
				.requestMatchers("/user/**").hasAuthority("ROLE_USER")
				.requestMatchers("/admin/**").hasAuthority("ROLE_ADMIN").anyRequest().authenticated());
		http.sessionManagement(session -> 
		session.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED));

		http.formLogin(form -> form
			    .loginPage("/public/login")
			    .usernameParameter("email")   // 👈 yeh add karo
			    .passwordParameter("password")
			    .loginProcessingUrl("/login")
			    .successHandler(new CustomLoginSuccessHandler())
			    .failureUrl("/public/login?error=true")
			    .permitAll());
		http.logout(logout -> logout
		    	   .logoutUrl("/logout")
			          .logoutSuccessUrl("/login?logout=true"));

		return http.build();
	}
	
	@Bean
	PasswordEncoder encoder() {
		return new BCryptPasswordEncoder();
	}
}
