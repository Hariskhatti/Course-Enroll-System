package hello.security.main.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import hello.security.main.entities.CourseEntity;
import hello.security.main.entities.EnrollmentEntity;
import hello.security.main.entities.EnrollmentStatus;
import hello.security.main.entities.StudentEntity;
import hello.security.main.repository.EnrollmentRepository;
import hello.security.main.repository.StudentRepository;
import hello.security.main.serviceLayer.ServiceInterface;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private ServiceInterface si;
	@Autowired
	private EnrollmentRepository er;
	@Autowired
	private StudentRepository sr;
	@GetMapping("/admin-dashboard")
	String dashboard() {
		return "admin-dashboard";
	}
	
	@GetMapping("/add-course")
	String addCourse(Model model) {
		model.addAttribute("modelObj" ,new CourseEntity());
		return "add-course";
	}
	@PostMapping("/add-courses")
	String addCoursee(@ModelAttribute CourseEntity ce, Model model) {

	    si.saveCourse(ce);

	    model.addAttribute("successMessage", "Course added successfully!");
	    model.addAttribute("modelObj", new CourseEntity()); // ⭐ MUST

	    return "add-course";
	}

	@GetMapping("/manage-course")
	String manageCourse(Model model) {
		model.addAttribute("modelObj", si.getAllCourses());
		return "manage-course";
	}
	
	@PostMapping("/delete-course/{id}")
	public String deleteCourse(@PathVariable Long id,
	                           RedirectAttributes redirectAttributes) {

	    si.deleteCourseById(id);   // service layer call

	    redirectAttributes.addFlashAttribute(
	        "successMessage", "Course deleted successfully!"
	    );
	    return "redirect:/admin/manage-course";
	}
	
	@GetMapping("/enrollment-requests")
	String enrollmentRequests(Model model) {
		List<EnrollmentEntity> list = er.findByStatus(EnrollmentStatus.PENDING);
		model.addAttribute("modelObj", list);
		return "enrollment-requests";
	}
	
	@PostMapping("/approve/{enrollId}")
	public String approveCourseRequest(@PathVariable Long enrollId, Principal principal, RedirectAttributes ra) {
		String username = principal.getName();
		StudentEntity logedInAdmin = sr.findByEmail(username);
		si.approveRequest(enrollId, logedInAdmin);
	    ra.addFlashAttribute("successMsg", "Enrollment approved successfully ");
	    return "redirect:/admin/enrollment-requests";
	}
	@PostMapping("/reject/{enrollId}")
	public String rejectCourseRequest(@PathVariable Long enrollId, Principal principal, RedirectAttributes ra) {
		String username = principal.getName();
		StudentEntity logedInAdmin = sr.findByEmail(username);
		si.rejectRequest(enrollId, logedInAdmin);
	    ra.addFlashAttribute("errorMsg", "Enrollment rejected ");

	    return "redirect:/admin/enrollment-requests";
	}
}
